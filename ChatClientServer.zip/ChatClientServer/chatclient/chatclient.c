/*
Name : Khoa Tran
HW 7 : chatclient.c
Date : 5/3/2022
Pledge : I pledge my honor that I have abided by the Stevens Honor System.
*/
#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>

#include "util.h"

int client_socket = -1;
char username[MAX_NAME_LEN + 1];
char inbuf[BUFLEN + 1];
char outbuf[MAX_MSG_LEN + 1];

int handle_stdin(){
    int message_length;
    if((message_length = get_string(outbuf, MAX_MSG_LEN + 1)) == TOO_LONG) printf("Sorry, limit your message to %d characters.\n", MAX_MSG_LEN);
    else if(message_length == NO_INPUT) {
        return 0;
    }
    else {
        if (send(client_socket, outbuf, strlen(outbuf), 0) < 0) fprintf(stderr, "Error: Failed to send message to server. %s.\n", strerror(errno));
        if (strcmp(outbuf, "bye") == 0){
            printf("Goodbye.\n");
            exit(EXIT_SUCCESS);
        }
    }
    return 0;
}

int handle_client_socket(){
    int bytes_recvd;
    if((bytes_recvd = recv(client_socket, inbuf, BUFLEN -1, 0)) == -1){
        fprintf(stderr, "Warning: Failed to receive incoming message. %s.\n", strerror(errno));  
    }
    inbuf[bytes_recvd] = '\0';
    if(strcmp(inbuf, "bye") == 0) {
        printf("\nServer initiated shutdown.\n");
        return 1;
    } else if(bytes_recvd == 0){
        fprintf(stderr, "Connection to server has been lost.\n");
        close(client_socket);
        exit(EXIT_FAILURE);
    } else printf("\n%s\n", inbuf);
    return 0;
}

int main(int argc, char *argv[]){
    if(argc != 3){
        fprintf(stderr, "Usage: %s <server ip> <port>\n", argv[0]);
        return EXIT_FAILURE;
    }
    struct sockaddr_in serv_addr;
    memset(&serv_addr, 0, sizeof(struct sockaddr_in));
    int ip_conversion, bytes_recvd, port_number, username_value;  //initialized used values
    if((ip_conversion = inet_pton(AF_INET, argv[1], &serv_addr.sin_addr)) == 0){
        fprintf(stderr, "Error: Invalid IP address '%s'.\n", argv[1]);
        return EXIT_FAILURE;
    }
    if(parse_int(argv[2], &port_number, "port number") == false) return EXIT_FAILURE; //get port number
    if(port_number < 1024 || port_number > 65535){ //check if port number is in range
        fprintf(stderr, "Error: Port must be in range [1024, 65535].\n");
        return EXIT_FAILURE;
    }
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(port_number);
    while(1){
        printf("Choose a username: ");
        fflush(stdout);
        if((username_value = get_string(username, MAX_NAME_LEN+1)) == NO_INPUT){ //if username length is zero
            continue;
        } else if(username_value == TOO_LONG) {
            fprintf(stderr, "Sorry, limit your username to %d characters.\n", MAX_NAME_LEN);
        } else{
            break;
        }
    }
    printf("Hello, %s. Let's try to connect to the server.\n", username);
    if((client_socket = socket(AF_INET, SOCK_STREAM, 0)) < 0){          //create a socket 
        fprintf(stderr, "Error: Failed to create socket. %s. \n", strerror(errno));
        return EXIT_FAILURE;
    }
    if(connect(client_socket, (struct sockaddr *)&serv_addr, sizeof(struct sockaddr_in)) < 0){            //connect to server
        fprintf(stderr, "Error: Failed to connect to server. %s.\n", strerror(errno));
        if (fcntl(client_socket, F_GETFD) >= 0) close(client_socket);
        return EXIT_FAILURE;
    }
    if((bytes_recvd = recv(client_socket, inbuf, BUFLEN-1,0)) == -1){
        fprintf(stderr, "Error: Failed to receive message from server. %s.\n", strerror(errno));            //receive message from server
        if (fcntl(client_socket, F_GETFD) >= 0) close(client_socket);
        return EXIT_FAILURE;
    }
    if(bytes_recvd == 0){
        fprintf(stderr, "All connections are busy. Try again later.\n");                    //server full
        if (fcntl(client_socket, F_GETFD) >= 0) close(client_socket);
        return EXIT_FAILURE;
    }
    inbuf[bytes_recvd] = '\0'; //add null_terminator
    printf("\n%s\n\n", inbuf);
    fflush(stdout);
    fd_set file_dset;
    if(send(client_socket, username, strlen(username), 0) < 0) {
        fprintf(stderr, "Error: Failed to send username to server. %s. \n", strerror(errno));
        if (fcntl(client_socket, F_GETFD) >= 0) close(client_socket);
        return EXIT_FAILURE;
    }
    while(1){
        printf("[%s]: ", username);
        fflush(stdout);
        FD_ZERO(&file_dset);
        FD_SET(client_socket, &file_dset);
        FD_SET(0, &file_dset);
        int check = 0;
        if(select(client_socket+1, &file_dset, NULL, NULL, NULL) == -1 && errno != EINTR){
            fprintf(stderr, "Error: Failed in select. %s.\n", strerror(errno));
            if (fcntl(client_socket, F_GETFD) >= 0) close(client_socket);
            return EXIT_FAILURE;
        } else {
            if(FD_ISSET(client_socket, &file_dset)) check = handle_client_socket();
            if(FD_ISSET(STDIN_FILENO, &file_dset))  check = handle_stdin();
            if(check == 1){
                if (fcntl(client_socket, F_GETFD) >= 0) close(client_socket);
                return EXIT_FAILURE;
            }
        }
    }
    
}